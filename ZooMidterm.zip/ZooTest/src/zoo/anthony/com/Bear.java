package zoo.anthony.com;

public class Bear extends Animal {

    // This is a static counter which only tracks Bears
    private static int numOfBears;

    // This is a animal specific constructor adding the specific animals increment counter after it utilizes the parent constructor
    // (continued:) via the super class / extended Animal class.
    public Bear(String sex, String species, String weight, int age, String name, String id, String birthday, String color, String location, String state, String arrivalDate) {
        super(sex, species, weight, age, name, id, birthday, color, location, state, arrivalDate);
        numOfBears++;
    }

    //getter
    public static int getNumOfBears() {
        return numOfBears;
    }
}
