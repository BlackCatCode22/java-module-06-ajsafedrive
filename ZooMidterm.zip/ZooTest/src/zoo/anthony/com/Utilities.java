package zoo.anthony.com;

import java.util.Date;
import java.text.SimpleDateFormat;

public class Utilities {

    // This is a static method meaning it can be used without creating an object
    public static String arrivalDate() {
        // get the current date and time
        Date today = new Date();
        // create the date format
        SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
        SimpleDateFormat formatterYear = new SimpleDateFormat("yyyy");

        // Format the date / Store it
        String TodayDate = formatter.format(today);
        String Todayyear = formatterYear.format(today);

        // send the formatted date string back to where ever its being requested.
        return TodayDate;


    }


}
