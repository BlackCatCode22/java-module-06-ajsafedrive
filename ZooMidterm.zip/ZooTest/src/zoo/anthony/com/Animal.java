package zoo.anthony.com;

public class Animal {

    // This is a static variable and it tracks all the species count combined.
    private static int numOfAnimals;

    // These are animal properties that apply to all animals, they are private so they can only be altered within this class
    private String sex;
    private String species;
    private String weight;
    private int age;
    private String name;
    private String id;
    private String birthday;
    private String color;
    private String location;
    private String state;
    private String arrivalDate;

    // Constructor in which builds the Animal object
    public Animal(String sex, String species, String weight, int age, String name,
                  String id, String birthday, String color, String location,
                  String state, String arrivalDate) {

        // this.EXAMPLE is the variable, and the = is the parameter or the data passed in.
        this.sex = sex;
        this.species = species;
        this.weight = weight;
        this.age = age;
        this.name = name;
        this.id = id;
        this.birthday = birthday;
        this.color = color;
        this.location = location;
        this.state = state;
        this.arrivalDate = arrivalDate;

        // Increase the count of animals whenever a new one is created, regardless of species.
        numOfAnimals++;
    }

    // Static getter for number of animals
    public static int getNumOfAnimals() {
        return numOfAnimals;
    }

    // Getters and Setters to control private properties
    public String getSex() {
        return sex;
    }
    public void setSex(String sex) {
        this.sex = sex;
    }
    public String getSpecies() {
        return species;
    }
    public void setSpecies(String species) {
        this.species = species;
    }
    public String getWeight() {
        return weight;
    }
    public void setWeight(String weight) {
        this.weight = weight;
    }
    public int getAge() {
        return age;
    }
    public void setAge(int age) {
        this.age = age;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getBirthday() {
        return birthday;
    }
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }
    public String getColor() {
        return color;
    }
    public void setColor(String color) {
        this.color = color;
    }
    public String getLocation() {
        return location;
    }
    public void setLocation(String location) {
        this.location = location;
    }
    public String getState() {
        return state;
    }
    public void setState(String state) {
        this.state = state;
    }
    public String getArrivalDate() {
        return arrivalDate;
    }
    public void setArrivalDate(String arrivalDate) {
        this.arrivalDate = arrivalDate;
    }

    // THIS CODE CAN LIKELY BE DELETED, AS THIS IS HANDLED IN THE APP CLASS. KEEPING FOR NOW.
    /*public static int getNumOfHyena() {
        return Hyena.getNumOfHyenas(); //
    }*/

    // This toString makes the summary of the animal readable, and will authomatically run this method.
    @Override
    public String toString() {
        return "Animal{" +
                "name='" + name + '\'' +
                ", species='" + species + '\'' +
                ", age=" + age +
                ", sex='" + sex + '\'' +
                ", color='" + color + '\'' +
                ", location='" + location + '\'' +
                ", state='" + state + '\'' +
                ", arrivalDate='" + arrivalDate + '\'' +
                '}';
    }
}
