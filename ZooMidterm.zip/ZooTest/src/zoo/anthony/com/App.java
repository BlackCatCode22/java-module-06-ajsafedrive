package zoo.anthony.com;
// aJohnson
// Latest iteration: 11/2/25
// app.java / animal.java / hyena.java / lion.java / bear.java / tiger.java / utilities.java / animalNames.txt / arrivingAnimals.txt

// import all the tools

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Scanner;
import java.io.FileWriter;
import java.io.PrintWriter;

public class App {
    // MAIN PART OF THIS PROGRAM
    public static void main(String[] args) {

        // Creates a hashmap (KEY + VALUE) ( EX: HY01 + ANIMAL OBJECT)
        HashMap<String, Animal> AnimalMap = new HashMap<>();


        // Set the name of the file we want to import
        String filePath = "zoo/anthony/com/arrivingAnimals.txt";

        // set the name of the we want to export
        String outputFilePath = "zoo/anthony/com/zooPopulation.txt";

        // Utilizing buffered reader for the automatic close out.
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath));
             PrintWriter outputFile = new PrintWriter(new FileWriter(outputFilePath))) {
            String line;

            // This while loop reads the file line by line, if it reads null its at the end of the file.
            while ((line = reader.readLine()) != null) {

                //System.out.println(line);
                // Splits line by coma and space
                String[] ElementsOfInput = line.split(", ");

                // Debugging loop utilized, but no longer needed. Keeping for now.
                /*
                // for each loop for splitters each line
                int lineNum = 0;
                for(String thepart: ElementsOfInput){
                    System.out.println("element: " + lineNum + " " + thepart);
                   lineNum++;
                }
                 */

                // create variables to hold data that will be parsed.
                String sex;
                String species;
                String birthseason;
                String arrivaldate;
                String weight;
                weight = ElementsOfInput[3];
                String color;
                color = ElementsOfInput[2];
                String location;
                location = ElementsOfInput[4];
                String state;
                state = ElementsOfInput[5];

                // Parsing / splitting element 0
                String[] SplitElement0 = ElementsOfInput[0].split(" ");

                // converts a string into an integer
                int age = Integer.parseInt(SplitElement0[0]);
                sex = SplitElement0[3];
                species = SplitElement0[4];

                // Parsing / splitting element 1
                String[] SplitElement1 = ElementsOfInput[1].split(" ");
                birthseason = SplitElement1[2];


                // Hyena
                if (species.equals("hyena")) {
                    // creates a new hyena object using its standard constructor, then it passes the data from the parsed file.
                    // Utilities provides todays date.
                    Hyena hyena = new Hyena(sex, species, weight, age, "", "HY0" + Hyena.getNumOfHyenas(), ""
                            , color, location, state, Utilities.arrivalDate());
                    // Add hyena to our HashMap and its ID is HY01 and the file is the specific animal object.
                    AnimalMap.put(hyena.getId(), hyena);
                    // Print out the hyenas summary utilizing the toString() method
                    System.out.println(hyena);
                    // Prints out to the zooPopulation.txt file
                    outputFile.println(hyena);
                }

                // Lion
                if (species.equals("lion")) {
                    // creates a new lion object using its standard constructor, then it passes the data from the parsed file.
                    // Utilities provides todays date.
                    Lion lion = new Lion(sex, species, weight, age, "", "LI0" + Lion.getNumOfLions(), ""
                            , color, location, state, Utilities.arrivalDate());
                    // Add lion to our HashMap and its ID is LI01 and the file is the specific animal object.
                    AnimalMap.put(lion.getId(), lion);
                    // Print out the hyenas summary utilizing the toString() method
                    System.out.println(lion);
                    // Prints out to the zooPopulation.txt file
                    outputFile.println(lion);
                }

                // Tiger
                if (species.equals("tiger")) {
                    // creates a new tiger object using its standard constructor, then it passes the data from the parsed file.
                    // Utilities provides todays date.
                    Tiger tiger = new Tiger(sex, species, weight, age, "", "TI0" + Tiger.getNumOfTigers(), ""
                            , color, location, state, Utilities.arrivalDate());
                    // Add Tiger to our HashMap and its ID is TI01 and the file is the specific animal object.
                    AnimalMap.put(tiger.getId(), tiger);
                    // Print out the tigers summary utilizing the toString() method
                    System.out.println(tiger);
                    // Prints out to the zooPopulation.txt file
                    outputFile.println(tiger);
                }

                // Bear
                if (species.equals("bear")) {
                    // creates a new bear object using its standard constructor, then it passes the data from the parsed file.
                    // Utilities provides todays date.
                    Bear bear = new Bear(sex, species, weight, age, "", "BE0" + Bear.getNumOfBears(), ""
                            , color, location, state, Utilities.arrivalDate());
                    // Add Bear to our HashMap and its ID is BE01 and the file is the specific animal object.
                    AnimalMap.put(bear.getId(), bear);
                    // Print out the bears summary utilizing the toString() method
                    System.out.println(bear);
                    // Prints out to the zooPopulation.txt file
                    outputFile.println(bear);
                }
            }
        } catch (IOException e) {
            // This catch block is what to do if it breaks or the file is not found
            e.printStackTrace();
        }

        // Scanner object that takes user input
        Scanner input = new Scanner(System.in);

        // prints a summary of all the animals that were created.
        System.out.println("Current Animal IDs: " +
                "\n" + "HY01 + Index # of Hyenas" + "Count " + Hyena.getNumOfHyenas() +
                "\n" + "TI01 + Index # of Tigers" + "Count " + Tiger.getNumOfTigers() +
                "\n" + "LI01 + Index # of Lions" + "Count " + Lion.getNumOfLions() +
                "\n" + "BE01 + Index # of Hyenas" + "Count " + Bear.getNumOfBears());

        // requests user input
        System.out.println("Enter specific Animal ID for details: ");

        // stores the user input for next line
        String AnimalID = input.nextLine();

        // our hashmap provies the data from the key.
        System.out.println(AnimalMap.get(AnimalID));
    }
}



