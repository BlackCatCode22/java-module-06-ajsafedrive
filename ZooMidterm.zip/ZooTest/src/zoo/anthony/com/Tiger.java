package zoo.anthony.com;

public class Tiger extends Animal {

    // This is a static counter which only tracks Tigers
    private static int numOfTigers;

    // This is a animal specific constructor adding the specific animals increment counter after it utilizes the parent constructor
    // (continued:) via the super class / extended Animal class.
    public Tiger(String sex, String species, String weight, int age, String name, String id, String birthday, String color, String location, String state, String arrivalDate) {
        super(sex, species, weight, age, name, id, birthday, color, location, state, arrivalDate);
        numOfTigers++;
    }

    //getter
    public static int getNumOfTigers() {
        return numOfTigers;
    }
}
