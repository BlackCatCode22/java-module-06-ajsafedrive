package zoo.anthony.com;

public class Lion extends Animal {

    // This is a static counter which only tracks Lions
    private static int numOfLions;

    // This is a animal specific constructor adding the specific animals increment counter after it utilizes the parent constructor
    // (continued:) via the super class / extended Animal class.
    public Lion(String sex, String species, String weight, int age, String name, String id, String birthday, String color, String location, String state, String arrivalDate) {
        super(sex, species, weight, age, name, id, birthday, color, location, state, arrivalDate);
        numOfLions++;
    }

    //getter
    public static int getNumOfLions() {
        return numOfLions;
    }
}
